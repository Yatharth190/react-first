// ProductContext.js
import { createContext } from 'react';

export const ProductContext = createContext();
export const ProductContextProvider = ProductContext.Provider;
